"""
uploader.py
Uploads videos to YouTube using OAuth 2.0 with refresh tokens.
Supports multiple channels via different refresh token env vars.
"""

import os
import logging
import time
from typing import Optional, Dict
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

logger = logging.getLogger(__name__)

# YouTube API scopes
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

# Retry configuration
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds


def get_refresh_token(channel_id: str = "1") -> Optional[str]:
    """
    Get refresh token for a specific channel.
    Looks for YOUTUBE_REFRESH_TOKEN_CHANNEL_{channel_id} env var.
    Falls back to YOUTUBE_REFRESH_TOKEN if channel-specific not found.
    """
    env_var = f"YOUTUBE_REFRESH_TOKEN_CHANNEL_{channel_id}"
    token = os.getenv(env_var)

    if not token:
        token = os.getenv("YOUTUBE_REFRESH_TOKEN")
        if token:
            logger.warning(f"{env_var} not found, using fallback YOUTUBE_REFRESH_TOKEN")

    if not token:
        logger.error(f"No refresh token found for channel {channel_id}")
        return None

    return token


def get_credentials(channel_id: str = "1") -> Optional[Credentials]:
    """
    Build credentials from environment variables.
    Returns None if credentials cannot be built.
    """
    client_id = os.getenv("YOUTUBE_CLIENT_ID")
    client_secret = os.getenv("YOUTUBE_CLIENT_SECRET")
    refresh_token = get_refresh_token(channel_id)

    if not all([client_id, client_secret, refresh_token]):
        logger.error("Missing YouTube OAuth credentials in environment variables")
        return None

    creds = Credentials(
        token=None,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=client_id,
        client_secret=client_secret,
        scopes=SCOPES,
    )

    # Refresh the token to get a valid access token
    try:
        creds.refresh(Request())
        logger.info(f"Successfully refreshed access token for channel {channel_id}")
    except Exception as e:
        logger.error(f"Failed to refresh token: {e}")
        return None

    return creds


def get_youtube_service(channel_id: str = "1"):
    """Build and return the YouTube API service object."""
    creds = get_credentials(channel_id)
    if not creds:
        raise RuntimeError(f"Could not authenticate YouTube API for channel {channel_id}")

    return build("youtube", "v3", credentials=creds, cache_discovery=False)


def upload_video(
    video_path: str,
    title: str,
    description: str,
    tags: list,
    category_id: str = "27",
    privacy_status: str = "public",
    channel_id: str = "1",
    made_for_kids: bool = False,
) -> Optional[Dict]:
    """
    Upload a video to YouTube.
    Returns the API response dict on success, None on failure.
    """
    if not os.path.exists(video_path):
        logger.error(f"Video file not found: {video_path}")
        return None

    youtube = get_youtube_service(channel_id)

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags,
            "categoryId": category_id,
        },
        "status": {
            "privacyStatus": privacy_status,
            "selfDeclaredMadeForKids": made_for_kids,
        },
    }

    media = MediaFileUpload(
        video_path,
        mimetype="video/mp4",
        resumable=True,
    )

    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
    )

    # Execute with retries
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            logger.info(f"Uploading video (attempt {attempt}/{MAX_RETRIES}): {title}")
            response = request.execute()
            video_id = response.get("id")
            logger.info(f"Upload successful! Video ID: {video_id}")
            logger.info(f"Video URL: https://youtube.com/watch?v={video_id}")
            return response
        except Exception as e:
            logger.error(f"Upload attempt {attempt} failed: {e}")
            if attempt < MAX_RETRIES:
                logger.info(f"Retrying in {RETRY_DELAY} seconds...")
                time.sleep(RETRY_DELAY)
            else:
                logger.error("All upload attempts failed")
                return None

    return None


def upload_with_metadata(
    video_path: str,
    metadata: Dict,
    channel_id: str = "1",
) -> Optional[Dict]:
    """
    Upload a video using a metadata dictionary.
    Metadata should contain: title, description, tags, category_id, privacy_status
    """
    return upload_video(
        video_path=video_path,
        title=metadata.get("title", "Untitled Video"),
        description=metadata.get("description", ""),
        tags=metadata.get("tags", []),
        category_id=metadata.get("category_id", "27"),
        privacy_status=metadata.get("privacy_status", "public"),
        channel_id=channel_id,
    )


if __name__ == "__main__":
    # Test upload (requires valid credentials)
    print("Uploader module loaded. Set environment variables to test upload.")
