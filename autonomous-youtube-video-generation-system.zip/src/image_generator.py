"""
image_generator.py
Generates procedural visuals for PROCESS and BUILD phases.
Uses Pillow to create abstract, satisfying geometric images.
No external AI APIs required — 100% programmatic generation.
"""

import os
import math
import random
import logging
from typing import List, Dict
from PIL import Image, ImageDraw, ImageFont

logger = logging.getLogger(__name__)

# Vertical 1080x1920 for YouTube Shorts
VIDEO_WIDTH = int(os.getenv("VIDEO_WIDTH", "1080"))
VIDEO_HEIGHT = int(os.getenv("VIDEO_HEIGHT", "1920"))


def _random_color(palette: str = "warm") -> tuple:
    """Returns a random color from a curated palette."""
    palettes = {
        "warm": [
            (255, 107, 107), (255, 159, 67), (255, 206, 84),
            (255, 99, 72), (255, 71, 87), (255, 165, 2),
        ],
        "cool": [
            (112, 161, 255), (30, 144, 255), (46, 213, 115),
            (123, 237, 159), (7, 153, 146), (72, 219, 251),
        ],
        "neutral": [
            (223, 228, 234), (220, 221, 225), (245, 246, 250),
            (206, 214, 224), (241, 242, 246), (200, 214, 229),
        ],
        "dark": [
            (47, 54, 64), (53, 59, 72), (30, 39, 46),
            (72, 84, 96), (87, 96, 111), (119, 140, 163),
        ],
    }
    chosen = palettes.get(palette, palettes["warm"])
    return random.choice(chosen)


def _gradient_background(width: int, height: int, color1: tuple, color2: tuple) -> Image.Image:
    """Creates a vertical gradient background."""
    img = Image.new("RGB", (width, height))
    for y in range(height):
        ratio = y / height
        r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
        g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
        b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
        img.paste((r, g, b), (0, y, width, y + 1))
    return img


def _draw_text_centered(draw: ImageDraw.Draw, text: str, y: int, font_size: int, color: tuple, width: int):
    """Draws centered text on the image."""
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    x = (width - text_width) // 2
    draw.text((x, y), text, fill=color, font=font)


def generate_phase_image(phase_name: str, phase_text: str, output_path: str, index: int) -> str:
    """
    Generates a visually distinct image for a single phase.
    Uses different geometric patterns per phase to create visual variety.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    logger.info(f"Generating image for phase '{phase_name}' -> {output_path}")

    # Randomize palette per phase
    palette_choices = ["warm", "cool", "neutral", "dark"]
    palette = palette_choices[index % len(palette_choices)]
    bg_color1 = _random_color(palette)
    bg_color2 = _random_color(palette)

    img = _gradient_background(VIDEO_WIDTH, VIDEO_HEIGHT, bg_color1, bg_color2)
    draw = ImageDraw.Draw(img)

    # Draw decorative geometric shapes based on phase
    if phase_name == "declaration":
        # Bold centered circle with radiating lines
        center_x, center_y = VIDEO_WIDTH // 2, VIDEO_HEIGHT // 3
        radius = 150 + random.randint(0, 50)
        draw.ellipse([center_x - radius, center_y - radius, center_x + radius, center_y + radius],
                     fill=(255, 255, 255, 30), outline=(255, 255, 255), width=4)
        for angle in range(0, 360, 30):
            rad = math.radians(angle)
            x2 = center_x + int((radius + 80) * math.cos(rad))
            y2 = center_y + int((radius + 80) * math.sin(rad))
            draw.line([(center_x, center_y), (x2, y2)], fill=(255, 255, 255), width=2)

    elif phase_name == "assessment":
        # Grid of small squares
        square_size = 40
        gap = 20
        start_y = VIDEO_HEIGHT // 4
        for row in range(8):
            for col in range(6):
                x = 100 + col * (square_size + gap)
                y = start_y + row * (square_size + gap)
                fill = (255, 255, 255) if random.random() > 0.5 else (*bg_color2,)
                draw.rectangle([x, y, x + square_size, y + square_size], fill=fill, outline=(255, 255, 255), width=1)

    elif phase_name == "isolation":
        # Concentric circles
        center_x, center_y = VIDEO_WIDTH // 2, VIDEO_HEIGHT // 3
        for r in range(50, 300, 40):
            draw.ellipse([center_x - r, center_y - r, center_x + r, center_y + r],
                         outline=(255, 255, 255), width=2)

    elif phase_name == "process":
        # Progress bars / building blocks
        bar_width = 600
        bar_height = 30
        start_y = VIDEO_HEIGHT // 4
        for i in range(10):
            y = start_y + i * 60
            progress = (i + 1) / 10
            filled_width = int(bar_width * progress)
            draw.rectangle([240, y, 240 + bar_width, y + bar_height], outline=(255, 255, 255), width=2)
            draw.rectangle([240, y, 240 + filled_width, y + bar_height], fill=(255, 255, 255))

    elif phase_name == "build":
        # Pyramid / stacked blocks
        center_x = VIDEO_WIDTH // 2
        start_y = VIDEO_HEIGHT // 4
        block_size = 60
        for row in range(6):
            blocks_in_row = 6 - row
            row_width = blocks_in_row * block_size
            start_x = center_x - row_width // 2
            for col in range(blocks_in_row):
                x = start_x + col * block_size
                y = start_y + row * (block_size + 10)
                draw.rectangle([x, y, x + block_size - 5, y + block_size - 5],
                               fill=(255, 255, 255), outline=bg_color1, width=2)

    # Draw phase label and text
    _draw_text_centered(draw, phase_name.upper(), VIDEO_HEIGHT - 400, 48, (255, 255, 255), VIDEO_WIDTH)
    # Wrap text roughly
    words = phase_text.split()
    lines = []
    current_line = ""
    for word in words:
        if len(current_line) + len(word) < 40:
            current_line += word + " "
        else:
            lines.append(current_line.strip())
            current_line = word + " "
    if current_line:
        lines.append(current_line.strip())

    y_offset = VIDEO_HEIGHT - 320
    for line in lines[:6]:  # limit lines
        _draw_text_centered(draw, line, y_offset, 28, (255, 255, 255), VIDEO_WIDTH)
        y_offset += 40

    img.save(output_path)
    logger.info(f"Image saved: {output_path}")
    return output_path


def generate_images_for_phases(script: Dict, output_dir: str, timestamp: str) -> List[str]:
    """
    Generates one image per phase from the script.
    Returns a list of image file paths in phase order.
    """
    phases = script.get("phases", {})
    image_paths = []
    phase_order = ["declaration", "assessment", "isolation", "process", "build"]

    for idx, phase_name in enumerate(phase_order):
        phase_text = phases.get(phase_name, "")
        output_path = os.path.join(output_dir, f"img_{timestamp}_{phase_name}.png")
        path = generate_phase_image(phase_name, phase_text, output_path, idx)
        image_paths.append(path)

    return image_paths


if __name__ == "__main__":
    sample_script = {
        "phases": {
            "declaration": "You keep starting things, but you never finish them.",
            "assessment": "It starts with a spark of motivation. You feel unstoppable.",
            "isolation": "The turning point isn't a new strategy. It's a single, small commitment.",
            "process": "Now, watch what happens when you stack small wins.",
            "build": "This is what finishing looks like. Not perfect. Just done.",
        }
    }
    paths = generate_images_for_phases(sample_script, "output", "test")
    print("Generated images:", paths)
