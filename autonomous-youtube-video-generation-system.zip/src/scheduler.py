"""
scheduler.py
Orchestrates the full YouTube automation pipeline end-to-end.
"""

import os
import logging
import traceback
from datetime import datetime

from src.script_generator import generate_script
from src.image_generator import generate_images_for_phases
from src.audio_generator import generate_audio_from_script
from src.video_generator import assemble_video
from src.metadata_engine import generate_metadata
from src.uploader import upload_video

logger = logging.getLogger(__name__)


def run_daily_job(test_mode: bool = False) -> dict:
    """
    Runs the full pipeline:
      1. Generate script
      2. Generate images
      3. Generate audio
      4. Assemble video
      5. Generate metadata
      6. Upload to YouTube (if not test_mode)

    Returns a dict with results and paths.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.getenv("OUTPUT_DIR", "output")
    logs_dir = os.getenv("LOGS_DIR", "logs")
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)

    result = {
        "timestamp": timestamp,
        "test_mode": test_mode,
        "script": None,
        "images": [],
        "audio": None,
        "video": None,
        "metadata": None,
        "upload": None,
        "success": False,
        "error": None,
    }

    try:
        # Step 1: Generate Script
        logger.info("=== STEP 1: Generating Script ===")
        script = generate_script()
        result["script"] = script
        logger.info(f"Script generated. Title: {script['title']}")

        # Step 2: Generate Images
        logger.info("=== STEP 2: Generating Images ===")
        images = generate_images_for_phases(script, output_dir, timestamp)
        result["images"] = images
        logger.info(f"Generated {len(images)} images.")

        # Step 3: Generate Audio
        logger.info("=== STEP 3: Generating Audio ===")
        audio_path = os.path.join(output_dir, f"audio_{timestamp}.mp3")
        audio = generate_audio_from_script(script["full_narration"], audio_path)
        result["audio"] = audio
        logger.info(f"Audio generated: {audio}")

        # Step 4: Assemble Video
        logger.info("=== STEP 4: Assembling Video ===")
        video_path = os.path.join(output_dir, f"video_{timestamp}.mp4")
        video = assemble_video(images, audio, video_path)
        result["video"] = video
        logger.info(f"Video assembled: {video}")

        # Step 5: Generate Metadata
        logger.info("=== STEP 5: Generating Metadata ===")
        metadata = generate_metadata(script)
        result["metadata"] = metadata
        logger.info(f"Metadata generated. Title: {metadata['title']}")

        # Step 6: Upload (if not test mode)
        if not test_mode:
            logger.info("=== STEP 6: Uploading to YouTube ===")
            channel_id = os.getenv("CHANNEL_ID", "1")
            upload_result = upload_video(
                video_path=video,
                title=metadata["title"],
                description=metadata["description"],
                tags=metadata["tags"],
                category_id=metadata.get("category_id", "27"),
                privacy_status=metadata.get("privacy_status", "public"),
                channel_id=channel_id,
            )
            result["upload"] = upload_result
            logger.info(f"Upload result: {upload_result}")
        else:
            logger.info("=== STEP 6: SKIPPED (Test Mode) ===")

        result["success"] = True
        logger.info("=== PIPELINE COMPLETED SUCCESSFULLY ===")

    except Exception as e:
        error_msg = f"Pipeline failed: {str(e)}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        result["error"] = error_msg

    return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    res = run_daily_job(test_mode=True)
    print(res)
