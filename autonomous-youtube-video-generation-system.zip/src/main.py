"""
main.py
Entry point for the YouTube automation system.
Supports normal mode and test mode.
"""

import os
import sys
import argparse
import logging
from dotenv import load_dotenv

# Ensure src is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.scheduler import run_daily_job


def setup_logging():
    logs_dir = os.getenv("LOGS_DIR", "logs")
    os.makedirs(logs_dir, exist_ok=True)
    log_file = os.path.join(logs_dir, "automation.log")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )


def main():
    parser = argparse.ArgumentParser(description="YouTube Automation System")
    parser.add_argument(
        "--test",
        action="store_true",
        help="Run in test mode (skip upload to YouTube)",
    )
    args = parser.parse_args()

    # Load environment variables
    load_dotenv()
    setup_logging()

    logger = logging.getLogger(__name__)
    logger.info("========================================")
    logger.info("YouTube Automation System Starting")
    logger.info(f"Mode: {'TEST' if args.test else 'PRODUCTION'}")
    logger.info("========================================")

    result = run_daily_job(test_mode=args.test)

    if result["success"]:
        logger.info("Automation completed successfully.")
        sys.exit(0)
    else:
        logger.error(f"Automation failed: {result.get('error', 'Unknown error')}")
        sys.exit(1)


if __name__ == "__main__":
    main()
