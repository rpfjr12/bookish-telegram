"""
metadata_engine.py
Generates SEO-friendly metadata for YouTube uploads.
- Title, description, tags
- Focus on safe, broad, motivational/educational themes
"""

import logging
from typing import List, Dict

logger = logging.getLogger(__name__)

# SEO keyword pools for different content categories
KEYWORD_POOLS = {
    "mindset": [
        "mindset", "growth mindset", "mental clarity", "positive thinking",
        "self improvement", "personal growth", "inner peace", "mental strength",
        "mindfulness", "self awareness", "emotional intelligence", "resilience"
    ],
    "productivity": [
        "productivity", "focus", "deep work", "time management", "efficiency",
        "getting things done", "work smarter", "concentration", "flow state",
        "discipline", "habits", "routine", "goal setting"
    ],
    "creativity": [
        "creativity", "creative thinking", "innovation", "inspiration",
        "artistic mindset", "imagination", "creative process", "original ideas",
        "creative blocks", "brainstorming", "creative flow", "self expression"
    ],
    "learning": [
        "learning", "knowledge", "wisdom", "education", "self education",
        "curiosity", "lifelong learning", "skill development", "mastery",
        "study tips", "memory techniques", "cognitive growth", "intellectual"
    ],
    "habits": [
        "habits", "daily habits", "morning routine", "evening routine",
        "healthy habits", "habit formation", "consistency", "discipline",
        "self discipline", "willpower", "behavior change", "atomic habits"
    ],
    "emotions": [
        "emotions", "emotional health", "feelings", "emotional awareness",
        "empathy", "compassion", "gratitude", "happiness", "joy",
        "emotional balance", "mental wellness", "self compassion"
    ],
    "growth": [
        "growth", "self development", "becoming better", "transformation",
        "evolution", "progress", "journey", "path", "awakening",
        "self discovery", "potential", "unlock your potential"
    ],
}

# Universal tags that work for all videos
UNIVERSAL_TAGS = [
    "motivation", "inspiration", "self improvement", "personal development",
    "mindset", "growth", "positive", "encouragement", "wisdom",
    "life lessons", "reflection", "meaning", "purpose"
]

# Call-to-action templates
CTA_TEMPLATES = [
    "If this resonated with you, save it for later.",
    "Which part hit home the most? Let me know in the comments.",
    "Share this with someone who needs to hear it today.",
    "Follow for more daily insights.",
    "Bookmark this for your next moment of doubt.",
]


def detect_category(script: dict) -> str:
    """Detect the primary content category from the script."""
    text = f"{script.get('title', '')} {script.get('description', '')} {script.get('narration', '')}".lower()

    category_scores = {}
    for category, keywords in KEYWORD_POOLS.items():
        score = sum(1 for kw in keywords if kw in text)
        category_scores[category] = score

    best_category = max(category_scores, key=category_scores.get)
    if category_scores[best_category] == 0:
        return "growth"  # default
    return best_category


def generate_title(script: dict) -> str:
    """Generate an SEO-friendly, engaging title."""
    # Use the script's title as base, enhance if needed
    title = script.get("title", "")

    # Add engagement hooks for certain patterns
    hooks = [
        "The Truth About",
        "Why You Should",
        "The Real Reason",
        "What Nobody Tells You About",
        "How to Actually",
        "The Secret to",
    ]

    # If title is too short, enhance it
    if len(title) < 30:
        hook = hooks[hash(title) % len(hooks)]
        title = f"{hook} {title}"

    # Ensure title is YouTube-friendly (under 100 chars)
    if len(title) > 100:
        title = title[:97] + "..."

    logger.info(f"Generated title: {title}")
    return title


def generate_description(script: dict, video_url: str = "") -> str:
    """Generate a comprehensive video description."""
    lines = [
        script.get("description", ""),
        "",
        "🎯 In this video:",
    ]

    # Add phase summaries
    phases = script.get("phases", {})
    for phase_name, phase_text in phases.items():
        short_summary = phase_text[:80] + "..." if len(phase_text) > 80 else phase_text
        lines.append(f"• {phase_name}: {short_summary}")

    lines.extend([
        "",
        "💡 Key Takeaway:",
        phases.get("isolation", "Discover the insight that changes everything."),
        "",
        "⏱️ Timestamps:",
        "0:00 Declaration",
        "0:15 Assessment",
        "0:30 Isolation",
        "0:45 Process",
        "0:55 Build",
        "",
    ])

    # Add random CTA
    import random
    lines.append(random.choice(CTA_TEMPLATES))
    lines.append("")

    # Add hashtags
    category = detect_category(script)
    hashtags = [f"#{tag.replace(' ', '')}" for tag in KEYWORD_POOLS.get(category, [])[:5]]
    lines.append(" ".join(hashtags))

    if video_url:
        lines.extend(["", f"🔗 Watch more: {video_url}"])

    description = "\n".join(lines)
    logger.info(f"Generated description ({len(description)} chars)")
    return description


def generate_tags(script: dict) -> List[str]:
    """Generate relevant tags for the video."""
    category = detect_category(script)
    category_tags = KEYWORD_POOLS.get(category, [])

    # Combine universal + category-specific tags
    all_tags = list(set(UNIVERSAL_TAGS + category_tags))

    # Add title words as tags
    title = script.get("title", "")
    title_words = [w.lower() for w in title.split() if len(w) > 3]
    all_tags.extend(title_words)

    # Deduplicate and limit to 500 chars total (YouTube limit)
    unique_tags = []
    total_len = 0
    for tag in all_tags:
        tag = tag.strip().lower()
        if tag not in unique_tags and total_len + len(tag) + 1 <= 500:
            unique_tags.append(tag)
            total_len += len(tag) + 1

    logger.info(f"Generated {len(unique_tags)} tags")
    return unique_tags


def generate_metadata(script: dict, video_url: str = "") -> Dict:
    """
    Generates complete metadata package for a video.
    Returns dict with title, description, tags, category.
    """
    logger.info("Generating metadata...")

    metadata = {
        "title": generate_title(script),
        "description": generate_description(script, video_url),
        "tags": generate_tags(script),
        "category_id": "27",  # Education category on YouTube
        "privacy_status": "public",
    }

    logger.info("Metadata generation complete")
    return metadata


if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from src.script_generator import generate_script
    script = generate_script()
    meta = generate_metadata(script)
    print("Title:", meta["title"])
    print("Tags:", meta["tags"][:10])
