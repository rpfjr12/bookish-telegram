"""
audio_generator.py
Generates narration audio from script text using free TTS.
Primary: gTTS (Google Text-to-Speech, free, no API key needed).
"""

import os
import logging
from typing import Optional
from gtts import gTTS

logger = logging.getLogger(__name__)


def generate_audio(text: str, output_path: str, lang: str = "en", slow: bool = False) -> str:
    """
    Converts text to speech using gTTS and saves to output_path.
    Returns the output file path.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    logger.info(f"Generating audio with gTTS (lang={lang}, slow={slow}) -> {output_path}")
    tts = gTTS(text=text, lang=lang, slow=slow)
    tts.save(output_path)
    logger.info(f"Audio saved: {output_path}")
    return output_path


def split_text_into_chunks(text: str, max_chars: int = 5000) -> list:
    """Splits long text into chunks that fit gTTS limits."""
    chunks = []
    while len(text) > max_chars:
        split_point = text.rfind(" ", 0, max_chars)
        if split_point == -1:
            split_point = max_chars
        chunks.append(text[:split_point].strip())
        text = text[split_point:].strip()
    if text:
        chunks.append(text)
    return chunks


def generate_audio_from_script(script_text: str, output_path: str, lang: str = "en") -> str:
    """
    Generates a single audio file from the full script narration.
    Handles long text by splitting and concatenating if needed.
    """
    chunks = split_text_into_chunks(script_text)
    if len(chunks) == 1:
        return generate_audio(chunks[0], output_path, lang=lang)

    # For multiple chunks, generate temporary files and concatenate using ffmpeg
    temp_files = []
    for idx, chunk in enumerate(chunks):
        temp_path = output_path.replace(".mp3", f"_part_{idx}.mp3")
        generate_audio(chunk, temp_path, lang=lang)
        temp_files.append(temp_path)

    # Concatenate with ffmpeg
    concat_list = output_path.replace(".mp3", "_concat_list.txt")
    with open(concat_list, "w") as f:
        for temp_file in temp_files:
            f.write(f"file '{os.path.abspath(temp_file)}'\n")

    cmd = f"ffmpeg -y -f concat -safe 0 -i {concat_list} -acodec copy {output_path}"
    logger.info(f"Concatenating audio chunks: {cmd}")
    os.system(cmd)

    # Cleanup temp files
    for temp_file in temp_files:
        if os.path.exists(temp_file):
            os.remove(temp_file)
    if os.path.exists(concat_list):
        os.remove(concat_list)

    return output_path


if __name__ == "__main__":
    sample_text = "This is a test of the text to speech system. It works great and is completely free."
    generate_audio(sample_text, "output/test_audio.mp3")
