"""
script_generator.py
Generates YouTube video scripts following a strict 5-phase structure.
Topics are safe, universally relatable, and emotionally compelling.
"""

import random
import json
from datetime import datetime
from typing import Dict, List

# Safe, high-engagement topic pools
DECLARATION_TEMPLATES = [
    "You keep starting things, but you never finish them.",
    "The most productive people don't work harder—they work clearer.",
    "Your environment is silently shaping your habits.",
    "Small decisions compound into the life you're living right now.",
    "The gap between who you are and who you want to be is smaller than you think.",
    "You don't need more time. You need better focus.",
    "Most people overestimate what they can do in a day and underestimate what they can do in a year.",
    "Your brain is designed to avoid discomfort. That's why change feels hard.",
    "The best ideas usually come when you stop forcing them.",
    "You're not lazy. You're just disconnected from your own momentum.",
]

ASSESSMENT_TEMPLATES = [
    "It starts with a spark of motivation. You feel unstoppable. But somewhere along the way, the energy fades and the project sits unfinished.",
    "We live in a world built for distraction. Notifications, noise, endless scrolling. It's not a willpower problem—it's a design problem.",
    "Every room you enter, every screen you unlock, every routine you repeat is quietly training your brain what to expect next.",
    "One skipped workout. One late night. One 'I'll do it tomorrow.' They seem harmless alone. But they stack. And the stack becomes the story.",
    "We imagine transformation as a dramatic moment. In reality, it's a quiet series of choices made when no one is watching.",
    "Time isn't the issue. It's the mental switching cost. Every interruption resets your brain. By the end of the day, you've done everything and nothing.",
    "We set bold goals on Sunday night. By Wednesday, the excitement is gone. The problem isn't the goal. It's the system around it.",
    "Your brain isn't broken. It's efficient. It avoids energy-heavy tasks and seeks comfort. Understanding this changes everything.",
    "Creativity doesn't arrive on command. It shows up in the gaps—in walks, showers, moments of stillness. But we rarely create those gaps.",
    "Laziness is rarely the real problem. Usually, it's unclear priorities, hidden friction, or a goal that doesn't actually matter to you.",
]

ISOLATION_TEMPLATES = [
    "The turning point isn't a new strategy. It's a single, small commitment you refuse to break.",
    "The insight most people miss: clarity beats intensity. One clear hour outperforms four distracted ones.",
    "The key isn't changing everything at once. It's changing one trigger in your environment.",
    "Here's the shift: stop measuring your day by what you finished. Start measuring it by what you started well.",
    "The difference between stuck and moving is often one honest conversation with yourself about what you actually want.",
    "What if the problem isn't your effort—but your recovery? The best performers protect their rest as fiercely as their work.",
    "The hidden pattern: every breakthrough moment was preceded by a boring, repetitive phase no one saw.",
    "Instead of fighting your brain's preference for comfort, use it. Make the right choice the easy choice.",
    "The real block isn't a lack of ideas. It's the fear that the next one won't be good enough.",
    "What if motivation isn't the starting point? What if action creates motivation, not the other way around?",
]

PROCESS_TEMPLATES = [
    "Now, watch what happens when you stack small wins. One after another. Each one builds belief. Each one reshapes your identity.",
    "See the system forming. One clear boundary. One protected hour. One repeated ritual. The structure does the heavy lifting.",
    "Layer by layer, the environment shifts. The phone goes to another room. The workspace clears. The mind follows.",
    "Watch the compounding. One good choice makes the next one easier. Momentum isn't magic—it's math.",
    "Piece by piece, the gap closes. Not through force, but through consistency. The person you want to become is built in these quiet moments.",
    "Observe the rebuild. Focus isn't a talent. It's a practice. And like any practice, it strengthens with repetition.",
    "Step by step, the system replaces willpower. The goal becomes automatic. The resistance fades.",
    "Watch the pattern emerge. Rest, then work. Work, then rest. The rhythm becomes the engine.",
    "See the process unfold. Each repetition is a vote for the person you're becoming.",
    "Layer by layer, the foundation sets. Not dramatic. Not exciting. But undeniably effective.",
]

BUILD_TEMPLATES = [
    "This is what finishing looks like. Not perfect. Just done. And done is the only way forward.",
    "The result isn't a masterpiece. It's proof that you can trust yourself. And that changes everything.",
    "This is the moment most people miss. The quiet satisfaction of keeping a promise to yourself.",
    "It all comes together. Not because you felt like it—but because you built a system that doesn't depend on feelings.",
    "This is the reveal. Not of a finished product, but of a new standard. One you set. One you keep.",
    "The build completes. Not with fireworks, but with clarity. You know what works now. You know what to repeat.",
    "This is the payoff. Not the outcome—but the identity shift. You are no longer someone who tries. You are someone who does.",
    "The final piece clicks in. The rhythm is set. The path is clear. All that's left is to walk it.",
    "This is what consistency looks like from the outside. Quiet. Unremarkable. Until it isn't.",
    "The build is done. The real win? You now have a process you can repeat. Again and again.",
]


def generate_script() -> Dict:
    """
    Generates a complete script following the 5-phase structure.
    Returns a dict with phases, narration, title, description, and tags.
    """
    # Pick one random template from each phase
    declaration = random.choice(DECLARATION_TEMPLATES)
    assessment = random.choice(ASSESSMENT_TEMPLATES)
    isolation = random.choice(ISOLATION_TEMPLATES)
    process_narration = random.choice(PROCESS_TEMPLATES)
    build_narration = random.choice(BUILD_TEMPLATES)

    # Build full narration script
    full_narration = (
        f"{declaration}\n\n"
        f"{assessment}\n\n"
        f"{isolation}\n\n"
        f"{process_narration}\n\n"
        f"{build_narration}"
    )

    # Extract a title from the declaration
    title = declaration.replace(".", "").strip()

    # Build description
    description = (
        f"{title}.\n\n"
        f"This video explores a simple but powerful idea about mindset, productivity, and personal growth.\n\n"
        f"Topics covered:\n"
        f"- Self-improvement\n"
        f"- Building better habits\n"
        f"- Focus and clarity\n"
        f"- Mindset shifts\n\n"
        f"If this resonated, save it and come back when you need the reminder."
    )

    # Safe, high-performing tags
    tags = [
        "self improvement",
        "productivity",
        "mindset",
        "habits",
        "motivation",
        "focus",
        "personal growth",
        "discipline",
        "mental clarity",
        "growth mindset",
        "self discipline",
        "life advice",
        "better habits",
        "mindfulness",
        "success mindset",
    ]

    script_data = {
        "title": title,
        "description": description,
        "tags": tags,
        "phases": {
            "declaration": declaration,
            "assessment": assessment,
            "isolation": isolation,
            "process": process_narration,
            "build": build_narration,
        },
        "narration": full_narration,
        "full_narration": full_narration,
        "generated_at": datetime.utcnow().isoformat(),
    }

    return script_data


def save_script(script_data: Dict, output_path: str) -> str:
    """Saves the script to a JSON file. Returns the file path."""
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(script_data, f, indent=2, ensure_ascii=False)
    return output_path


if __name__ == "__main__":
    script = generate_script()
    print("Generated Script:")
    print(json.dumps(script, indent=2))
