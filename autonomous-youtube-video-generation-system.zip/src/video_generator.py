"""
video_generator.py
Assembles final vertical video using FFmpeg.
- Combines narration audio with background visuals.
- Creates a 1080x1920 vertical MP4.
- Ensures each of the 5 phases is represented in timing.
"""

import os
import logging
import subprocess
from typing import List

logger = logging.getLogger(__name__)

DEFAULT_WIDTH = 1080
DEFAULT_HEIGHT = 1920
DEFAULT_FPS = 30
DEFAULT_DURATION = 60  # seconds


def get_audio_duration(audio_path: str) -> float:
    """Get audio duration in seconds using ffprobe."""
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        audio_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return float(result.stdout.strip())
    except Exception as e:
        logger.warning(f"Could not get audio duration: {e}. Using default {DEFAULT_DURATION}s")
        return DEFAULT_DURATION


def create_video_from_images_and_audio(
    image_paths: List[str],
    audio_path: str,
    output_path: str,
    width: int = DEFAULT_WIDTH,
    height: int = DEFAULT_HEIGHT,
    fps: int = DEFAULT_FPS,
) -> str:
    """
    Creates a video from a list of images and an audio file.
    Each image is shown for an equal portion of the audio duration.
    Images are scaled/cropped to fill the vertical frame.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    if not image_paths:
        raise ValueError("No images provided for video generation")

    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    audio_duration = get_audio_duration(audio_path)
    logger.info(f"Audio duration: {audio_duration:.2f}s")

    # Calculate duration per image
    num_images = len(image_paths)
    duration_per_image = audio_duration / num_images
    logger.info(f"Showing {num_images} images, {duration_per_image:.2f}s each")

    # Create a temporary directory for processed frames
    temp_dir = os.path.join(os.path.dirname(output_path) or ".", "_temp_frames")
    os.makedirs(temp_dir, exist_ok=True)

    # Build FFmpeg concat demuxer input file
    concat_file = os.path.join(temp_dir, "concat_list.txt")
    with open(concat_file, "w") as f:
        for img_path in image_paths:
            abs_path = os.path.abspath(img_path)
            f.write(f"file '{abs_path}'\n")
            f.write(f"duration {duration_per_image}\n")
        # FFmpeg concat demuxer requires the last file repeated without duration
        f.write(f"file '{os.path.abspath(image_paths[-1])}'\n")

    # Build FFmpeg command
    # - loop 1: loop images
    # - vf: scale and crop to vertical format, add fade transitions
    filter_complex = (
        f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black,"
        f"fps={fps}"
    )

    cmd = [
        "ffmpeg",
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", concat_file,
        "-i", audio_path,
        "-vf", filter_complex,
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        output_path,
    ]

    logger.info(f"Running FFmpeg: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        logger.info(f"Video created successfully: {output_path}")
    except subprocess.CalledProcessError as e:
        logger.error(f"FFmpeg failed: {e.stderr}")
        raise RuntimeError(f"Video generation failed: {e.stderr}")
    finally:
        # Cleanup temp files
        if os.path.exists(concat_file):
            os.remove(concat_file)
        if os.path.exists(temp_dir):
            os.rmdir(temp_dir)

    return output_path


def create_video_with_procedural_background(
    audio_path: str,
    output_path: str,
    width: int = DEFAULT_WIDTH,
    height: int = DEFAULT_HEIGHT,
    fps: int = DEFAULT_FPS,
    duration: int = DEFAULT_DURATION,
) -> str:
    """
    Creates a video with a procedural animated background (color shifting)
    when no images are available.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    if os.path.exists(audio_path):
        audio_duration = get_audio_duration(audio_path)
    else:
        audio_duration = duration

    # Create a procedural animated background using FFmpeg's color source
    # with a hue rotation effect
    filter_complex = (
        f"color=c=black:s={width}x{height}:d={audio_duration}[bg];"
        f"[bg]hue=H=t*{360/audio_duration}:s=2[animated];"
        f"[animated]format=yuv420p"
    )

    cmd = [
        "ffmpeg",
        "-y",
        "-f", "lavfi",
        "-i", f"color=c=black:s={width}x{height}:d={audio_duration}",
        "-i", audio_path,
        "-vf", f"hue=H=t*{360/audio_duration}:s=2,format=yuv420p",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        output_path,
    ]

    logger.info(f"Running FFmpeg for procedural background: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        logger.info(f"Video with procedural background created: {output_path}")
    except subprocess.CalledProcessError as e:
        logger.error(f"FFmpeg failed: {e.stderr}")
        raise RuntimeError(f"Video generation failed: {e.stderr}")

    return output_path


def assemble_video(image_paths: List[str], audio_path: str, output_path: str) -> str:
    """
    Main entry point for video assembly.
    Uses images + audio if images exist, otherwise falls back to procedural background.
    """
    if image_paths and all(os.path.exists(p) for p in image_paths):
        return create_video_from_images_and_audio(image_paths, audio_path, output_path)
    else:
        logger.warning("No valid images provided. Using procedural background.")
        return create_video_with_procedural_background(audio_path, output_path)


if __name__ == "__main__":
    # Test with dummy files
    print("Video generator module loaded.")
