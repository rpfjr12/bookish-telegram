# YouTube Automation System

A fully autonomous YouTube video creation and upload pipeline that runs on GitHub Actions and GitHub Codespaces. Generates short-form vertical videos (1080x1920) with AI-generated scripts, procedural visuals, text-to-speech narration, and automatic YouTube uploads.

## Features

- **5-Phase Video Structure**: Declaration → Assessment → Isolation → Process (timelapse) → Build
- **Safe Content Only**: Mindset, productivity, creativity, habits, emotions, growth — no medical, financial, or political content
- **Fully Automated**: Runs on a daily schedule via GitHub Actions
- **Free Tools**: Uses gTTS (free TTS), Pillow (procedural images), and FFmpeg (video assembly)
- **Multi-Channel Support**: Upload to different channels via different refresh tokens
- **Test Mode**: Run locally without uploading to YouTube

## Project Structure

```
/workspace/
├── .github/
│   └── workflows/
│       └── youtube_automation.yml   # GitHub Actions workflow
├── src/
│   ├── script_generator.py          # Generates 5-phase scripts
│   ├── image_generator.py           # Procedural visuals for PROCESS/BUILD
│   ├── audio_generator.py           # gTTS narration
│   ├── video_generator.py           # FFmpeg assembly (1080x1920)
│   ├── metadata_engine.py           # SEO titles, descriptions, tags
│   ├── uploader.py                  # YouTube Data API upload
│   ├── scheduler.py                 # Orchestrates full pipeline
│   └── main.py                      # Entry point
├── assets/
│   └── fonts/                       # Fonts for text overlays
├── output/                          # Generated videos, audio, images
├── logs/                            # Execution logs
├── requirements.txt                 # Python dependencies
├── .env.example                     # Environment variable template
├── .gitignore                       # Git ignore rules
└── README.md                        # This file
```

## Setup

### 1. Clone and Open in Codespaces

```bash
git clone <your-repo-url>
cd <repo-name>
```

Or open directly in [GitHub Codespaces](https://github.com/features/codespaces).

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

On Ubuntu/Debian (including Codespaces), install FFmpeg:

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg
```

### 3. Configure Environment Variables

Copy the example file and fill in your values:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# YouTube OAuth 2.0 Credentials
# Create at https://console.cloud.google.com/apis/credentials
YOUTUBE_CLIENT_ID=your_client_id
YOUTUBE_CLIENT_SECRET=your_client_secret

# Refresh Tokens (one per channel)
YOUTUBE_REFRESH_TOKEN_CHANNEL_1=your_refresh_token_1
YOUTUBE_REFRESH_TOKEN_CHANNEL_2=your_refresh_token_2

# Which channel to use (1, 2, 3, ...)
CHANNEL_ID=1

# Optional: OpenAI for enhanced scripts
OPENAI_API_KEY=your_openai_key

# Optional: ElevenLabs for premium TTS
ELEVENLABS_API_KEY=your_elevenlabs_key
```

### 4. Get YouTube OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a project → Enable **YouTube Data API v3**
3. Go to **Credentials** → **Create OAuth 2.0 Client ID** (Desktop app)
4. Download client ID and secret, add to `.env`
5. Run the OAuth flow to get a refresh token:

```bash
python -c "
import os
from src.uploader import get_refresh_token
os.environ['YOUTUBE_CLIENT_ID'] = 'your_client_id'
os.environ['YOUTUBE_CLIENT_SECRET'] = 'your_client_secret'
get_refresh_token()
"
```

Copy the refresh token into `.env` as `YOUTUBE_REFRESH_TOKEN_CHANNEL_1`.

Repeat for each channel you want to use.

## Running Locally

### Test Mode (no upload)

```bash
python src/main.py --test
```

This generates the video and metadata but does NOT upload to YouTube.

### Production Mode (with upload)

```bash
python src/main.py
```

This runs the full pipeline including YouTube upload.

## GitHub Actions Automation

The workflow in `.github/workflows/youtube_automation.yml` runs daily at 10:00 UTC.

### Enable the Workflow

1. Push this repo to GitHub
2. Go to **Settings → Secrets and variables → Actions**
3. Add all secrets from `.env`:
   - `YOUTUBE_CLIENT_ID`
   - `YOUTUBE_CLIENT_SECRET`
   - `YOUTUBE_REFRESH_TOKEN_CHANNEL_1`
   - `YOUTUBE_REFRESH_TOKEN_CHANNEL_2` (optional)
   - `CHANNEL_ID`
   - `OPENAI_API_KEY` (optional)
   - `ELEVENLABS_API_KEY` (optional)

### Manual Trigger

Go to **Actions → YouTube Daily Automation → Run workflow**.

### Adjust Schedule

Edit the cron expression in `.github/workflows/youtube_automation.yml`:

```yaml
on:
  schedule:
    - cron: "0 10 * * *"   # Daily at 10:00 UTC
```

Use [crontab.guru](https://crontab.guru/) to customize.

## Content Safety

All generated content follows these rules:
- ✅ Mindset, productivity, creativity, learning, habits, emotions, growth
- ❌ No medical advice or health claims
- ❌ No financial promises or investment advice
- ❌ No political or controversial topics
- ❌ No dangerous or harmful activities
- ❌ No copyrighted media (only AI-generated or procedural assets)

## Customization

### Change Video Topics

Edit `TOPIC_TEMPLATES` in [`src/script_generator.py`](src/script_generator.py).

### Change Visual Style

Edit `PALETTES` and generation functions in [`src/image_generator.py`](src/image_generator.py).

### Change Voice/Language

Edit the `lang` parameter in [`src/audio_generator.py`](src/audio_generator.py). Supported languages: `en`, `es`, `fr`, `de`, `it`, `pt`, `ja`, `ko`, `zh`, etc.

### Add More Channels

1. Add a new refresh token env var: `YOUTUBE_REFRESH_TOKEN_CHANNEL_3`
2. Update `uploader.py` to handle the new token
3. Set `CHANNEL_ID=3` in your `.env` or GitHub Secrets

## Troubleshooting

| Issue | Solution |
|-------|----------|
| FFmpeg not found | Run `sudo apt-get install ffmpeg` |
| Upload quota exceeded | YouTube API has daily quotas; wait 24h or check [quota dashboard](https://console.cloud.google.com/apis/api/youtube.googleapis.com/quotas) |
| Invalid refresh token | Re-run the OAuth flow to generate a new token |
| Video too long/short | Adjust `VIDEO_DURATION_SECONDS` in `.env` |
| gTTS fails | Check internet connection; gTTS requires outbound HTTP |

## License

MIT License — use freely, modify as needed.
